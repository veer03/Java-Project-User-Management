package org.veer.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.veer.entity.User;
import org.veer.model.UsersModel;

@WebServlet("/site")
public class Site extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String page = request.getParameter("page").toLowerCase();
		switch (page) {
	
		case "listusers":
			listUsers(request, response);
			break;
			
		case "adduser":
			addUser(request, response);
			break;
			
		case "updateuser":
			updateUser(request, response);
			break;
			
		case "deleteuser":
			deleteUser(request, response);
			break;
			
		default:
			request.setAttribute("title", "Error Page");
			request.getRequestDispatcher("error.jsp").forward(request, response);
			break;
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String form = request.getParameter("form").toLowerCase();
		switch (form) {
	
		case "adduseroperation":
			User newUser = new User(request.getParameter("username"), request.getParameter("email"));
			new UsersModel().addUser(newUser);
			listUsers(request, response);
			break;
			
		case "updateuseroperation":
			User updatedUser = new User(Integer.parseInt(request.getParameter("user_id")), request.getParameter("username"), request.getParameter("email"));
			new UsersModel().updateUser(updatedUser);
			listUsers(request, response);
			break;
		
		default:
			request.setAttribute("title", "Error Page");
			request.getRequestDispatcher("error.jsp").forward(request, response);
			break;
			
		}
	}
	
	protected void listUsers(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<User> users = new ArrayList<>();
		users = new UsersModel().listUser();
		request.setAttribute("listUsers", users);
		request.setAttribute("title", "List Users");
		request.getRequestDispatcher("listusers.jsp").forward(request, response);
	}
	
	protected void addUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setAttribute("title", "Add User");
		request.getRequestDispatcher("adduser.jsp").forward(request, response);
	}

	protected void updateUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setAttribute("title", "Update User");
		request.getRequestDispatcher("updateuser.jsp").forward(request, response);
	}
	
	protected void deleteUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		new UsersModel().deleteUser(Integer.parseInt(request.getParameter("user_id")));
		listUsers(request, response);
	}
}
