package org.veer.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConfig {
	
		public static Connection getConnection() {
			
			//Initialize all the information regarding database connection
			String dbUrl = "jdbc:mysql://localhost:3306/studyeasy?useSSL=false";
			
			//Database name to access
			String dbUsername = "root";
			String dbPassword = "Hello@0310!";
			Connection con = null;
			
			try {
				Class.forName("com.mysql.cj.jdbc.Driver");
				con = DriverManager.getConnection(dbUrl, dbUsername, dbPassword);
			}catch(ClassNotFoundException e) {
				e.printStackTrace();
			}catch (SQLException e) {
				e.printStackTrace();
			}
			
			return con;
		}

}
