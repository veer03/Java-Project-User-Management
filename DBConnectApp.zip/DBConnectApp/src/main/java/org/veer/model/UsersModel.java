package org.veer.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.veer.config.DatabaseConfig;
import org.veer.entity.User;

public class UsersModel {

//		Listing Users
	public List<User> listUser() {
		List<User> listUsers = new ArrayList<User>();
		// Step 1: First connect with database
		Connection con = DatabaseConfig.getConnection();
		Statement stmt = null;
		ResultSet rs = null;

		// Step 2: Create the DB query.
		String query = "Select * from users";
		try {
			stmt = con.createStatement();

			// Step 3: Execute the statement.
			rs = stmt.executeQuery(query);
			while (rs.next()) {
				listUsers.add(new User(rs.getInt("user_id"), rs.getString("username"), rs.getString("email")));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return listUsers;
	}

//		Adding Users
	public void addUser(User newUser) {
		Connection con = null;
		PreparedStatement statement = null;

		try {
			con = DatabaseConfig.getConnection();
			String username = newUser.getUsername();
			String email = newUser.getEmail();
			String query = "insert into users(username, email) values (?, ?)";
			statement = con.prepareStatement(query);
			statement.setString(1, username);
			statement.setString(2, email);
			statement.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

//			Update User
	public void updateUser(User updatedUser) {
		Connection con = null;
		PreparedStatement statement = null;
		try {
			con = DatabaseConfig.getConnection();
			int userId = updatedUser.getUser_id();
			String username = updatedUser.getUsername();
			String email = updatedUser.getEmail();
			String query = "update users set username = ? , email= ? where user_id = ? ";
			statement = con.prepareStatement(query);
			statement.setString(1, username);
			statement.setString(2, email);
			statement.setInt(3, userId);
			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

//	Delete User
	public void deleteUser(int userId) {
		Connection con = null;
		PreparedStatement statement = null;
		try {
			con = DatabaseConfig.getConnection();
			String query = "delete from users where user_id = ? ";
			statement = con.prepareStatement(query);
			statement.setInt(1, userId);
			statement.execute();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
